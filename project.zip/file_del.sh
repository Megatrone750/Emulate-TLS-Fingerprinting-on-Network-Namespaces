#!/bin/bash
ip netns del red
ip netns del blue
ip netns del r1
ip netns del r2